package com.leyou.service.mapper;

import com.leyou.common.mapper.BaseMapper;
import com.leyou.item.pojo.Sku;

/**
 * @author bystander
 * @date 2018/9/18
 */
public interface SkuMapper extends BaseMapper<Sku, Long> {
}
