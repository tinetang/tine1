package com.leyou.service.mapper;

import com.leyou.item.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bystander
 * @date 2018/9/18
 */
public interface SpuMapper extends Mapper<Spu> {
}
