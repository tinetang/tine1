package com.leyou.order.mapper;

import com.leyou.order.pojo.Order;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bystander
 * @date 2018/10/4
 */
public interface OrderMapper extends Mapper<Order> {
}
