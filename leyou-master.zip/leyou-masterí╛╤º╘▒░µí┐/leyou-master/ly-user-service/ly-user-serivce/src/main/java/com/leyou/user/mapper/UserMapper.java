package com.leyou.user.mapper;

import com.leyou.user.pojo.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bystander
 * @date 2018/9/29
 */
public interface UserMapper extends Mapper<User> {
}
